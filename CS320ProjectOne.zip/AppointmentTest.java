// AppointmentTest.java
// Unit tests for Appointment.java to validate constructor logic and field constraints.

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    // Utility method: returns a date that is 1 day in the future (valid for appointments)
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTime();
    }

    // Utility method: returns a date that is 1 day in the past (invalid for appointments)
    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        return cal.getTime();
    }

    // Test: Valid appointment with correct ID, future date, and description
    @Test
    public void testValidAppointmentCreation() {
        Appointment appt = new Appointment("1234567890", getFutureDate(), "Routine check-up");
        assertEquals("1234567890", appt.getAppointmentId());
        assertNotNull(appt.getAppointmentDate());
        assertEquals("Routine check-up", appt.getDescription());
    }

    // Test: Null ID should throw IllegalArgumentException
    @Test
    public void testNullIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, getFutureDate(), "Test"));
    }

    // Test: Empty string as ID should throw exception
    @Test
    public void testEmptyIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("", getFutureDate(), "Test"));
    }

    // Test: ID longer than 10 characters should throw exception
    @Test
    public void testTooLongIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", getFutureDate(), "Test")); // 11 chars
    }

    // Test: Null appointment date should throw exception
    @Test
    public void testNullDateThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", null, "Test"));
    }

    // Test: Appointment date in the past should throw exception
    @Test
    public void testPastDateThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", getPastDate(), "Test"));
    }

    // Test: Null description should throw exception
    @Test
    public void testNullDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", getFutureDate(), null));
    }

    // Test: Empty description should throw exception
    @Test
    public void testEmptyDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", getFutureDate(), ""));
    }

    // Test: Description longer than 50 characters should throw exception
    @Test
    public void testTooLongDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", getFutureDate(), "A".repeat(51))); // 51 chars
    }

    // Test: Appointment ID with exactly 10 characters should be accepted
    @Test
    public void testIdExactly10CharactersAccepted() {
        Appointment appt = new Appointment("ABCDEFGHIJ", getFutureDate(), "Valid test");
        assertEquals("ABCDEFGHIJ", appt.getAppointmentId());
    }

    // Test: Description with exactly 50 characters should be accepted
    @Test
    public void testDescriptionExactly50CharactersAccepted() {
        String desc = "B".repeat(50); // 50-character string
        Appointment appt = new Appointment("1234567890", getFutureDate(), desc);
        assertEquals(desc, appt.getDescription());
    }
}