// TaskTest.java 
// Unit tests for the Task class to ensure all fields are validated correctly,
// including valid creation, boundary conditions, and exception handling for invalid inputs.

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    // Test valid task creation with correct inputs
    @Test
    public void testValidTaskCreation() {
        Task task = new Task("007", "Mission", "Retrieve intel from base.");
        assertEquals("007", task.getTaskId());
        assertEquals("Mission", task.getName());
        assertEquals("Retrieve intel from base.", task.getDescription());
    }

    // Test updating name and description using valid values
    @Test
    public void testUpdateFields() {
        Task task = new Task("007", "Mission", "Retrieve intel from base.");
        task.setName("Infiltrate");
        task.setDescription("Enter the facility silently.");
        assertEquals("Infiltrate", task.getName());
        assertEquals("Enter the facility silently.", task.getDescription());
    }

    // Test invalid name values during object creation: null, empty, too long
    @Test
    public void testInvalidNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("007", null, "Valid"));
        assertThrows(IllegalArgumentException.class, () -> new Task("007", "", "Valid"));
        assertThrows(IllegalArgumentException.class, () -> new Task("007", "A".repeat(21), "Valid"));
    }

    // Test invalid description values during object creation: null, empty, too long
    @Test
    public void testInvalidDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("007", "Valid", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("007", "Valid", ""));
        assertThrows(IllegalArgumentException.class, () -> new Task("007", "Valid", "A".repeat(51)));
    }

    // Test invalid taskId during object creation: null, empty, too long
    @Test
    public void testInvalidTaskIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("", "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("ABCDEFGHIJK", "Name", "Description")); // 11 characters
    }

    // Test invalid values for setName: null, empty, too long
    @Test
    public void testSetNameInvalidValues() {
        Task task = new Task("007", "Valid", "Valid");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName(""));
        assertThrows(IllegalArgumentException.class, () -> task.setName("A".repeat(21)));
    }

    // Test invalid values for setDescription: null, empty, too long
    @Test
    public void testSetDescriptionInvalidValues() {
        Task task = new Task("007", "Valid", "Valid");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(""));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("B".repeat(51)));
    }

    // Boundary test: taskId exactly 10 characters
    @Test
    public void testTaskIdExactly10Chars() {
        Task task = new Task("ABCDEFGHIJ", "EdgeCase", "Valid task ID at limit");
        assertEquals("ABCDEFGHIJ", task.getTaskId());
    }

    // Boundary test: name exactly 20 characters
    @Test
    public void testNameExactly20Chars() {
        String name = "A".repeat(20);
        Task task = new Task("001", name, "Valid description");
        assertEquals(name, task.getName());
    }

    // Boundary test: description exactly 50 characters
    @Test
    public void testDescriptionExactly50Chars() {
        String desc = "B".repeat(50);
        Task task = new Task("002", "DescTest", desc);
        assertEquals(desc, task.getDescription());
    }
}