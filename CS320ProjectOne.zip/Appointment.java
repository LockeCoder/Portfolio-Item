// Appointment.java
// Represents an appointment with ID, date, and description, including validation rules.

import java.util.Date;

public class Appointment {
    // The unique appointment ID (must be non-null, not empty, max 10 characters, immutable)
    private final String appointmentId;

    // The date of the appointment (must be non-null and not in the past, immutable)
    private final Date appointmentDate;

    // A description of the appointment (must be non-null, not empty, max 50 characters, immutable)
    private final String description;

    /**
     * Constructs a new Appointment object.
     *
     * Requirements (Project One Rubric):
     * - appointmentId: required, unique, ≤ 10 chars, non-null, not empty, not updatable
     * - appointmentDate: required, not null, must not be in the past
     * - description: required, non-null, ≤ 50 chars
     *
     * @param appointmentId   unique ID for the appointment
     * @param appointmentDate future date of appointment
     * @param description     brief description of the appointment
     * @throws IllegalArgumentException if any field is invalid
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate appointment ID
        if (appointmentId == null || appointmentId.trim().isEmpty() || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be non-null, non-empty, and max 10 characters.");
        }

        // Validate appointment date (must be in the future)
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be null or in the past.");
        }

        // Validate description
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null, non-empty, and max 50 characters.");
        }

        // Assign validated values
        this.appointmentId = appointmentId;
        this.appointmentDate = new Date(appointmentDate.getTime()); // Defensive copy for immutability
        this.description = description;
    }

    /**
     * Gets the appointment ID (read-only).
     * @return the appointment ID string
     */
    public String getAppointmentId() {
        return appointmentId;
    }

    /**
     * Gets the appointment date (returns a copy for immutability).
     * @return a new Date object representing the appointment date
     */
    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime());
    }

    /**
     * Gets the appointment description (read-only).
     * @return the appointment description
     */
    public String getDescription() {
        return description;
    }
}