// Task.java
// Defines a Task object with ID, name, and description.
// All fields are validated for non-null, length, and formatting constraints.

public class Task {
    private final String taskId;     // Required, not null/empty, max 10 characters, immutable
    private String name;             // Required, not null/empty, max 20 characters
    private String description;      // Required, not null/empty, max 50 characters

    /**
     * Constructs a new Task with the given ID, name, and description.
     *
     * Rubric Requirements:
     * - taskId: Required, not null or empty, max 10 characters, not updatable
     * - name: Required, not null or empty, max 20 characters, updatable
     * - description: Required, not null or empty, max 50 characters, updatable
     *
     * @param taskId unique identifier for the task (non-null, ≤10 chars)
     * @param name short task name (non-null, ≤20 chars)
     * @param description longer task detail (non-null, ≤50 chars)
     * @throws IllegalArgumentException if any constraint is violated
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.trim().isEmpty() || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must not be null, empty, or longer than 10 characters.");
        }
        if (name == null || name.trim().isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name must not be null, empty, or longer than 20 characters.");
        }
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null, empty, or longer than 50 characters.");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    /**
     * Returns the unique ID of the task. Cannot be modified.
     *
     * @return the task ID string
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * Gets the task's name.
     *
     * @return the task name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the task's description.
     *
     * @return the task description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Updates the task's name, validating length and null constraints.
     *
     * @param name the new task name (non-null, ≤20 chars)
     * @throws IllegalArgumentException if input is invalid
     */
    public void setName(String name) {
        if (name == null || name.trim().isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name must not be null, empty, or longer than 20 characters.");
        }
        this.name = name;
    }

    /**
     * Updates the task's description, validating length and null constraints.
     *
     * @param description the new task description (non-null, ≤50 chars)
     * @throws IllegalArgumentException if input is invalid
     */
    public void setDescription(String description) {
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null, empty, or longer than 50 characters.");
        }
        this.description = description;
    }
}