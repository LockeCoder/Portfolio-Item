// Contact.java
// Represents a contact with ID, name, phone number, and address, with strict validation for all fields.

public class Contact {
    private final String contactId;      // Required, max 10 chars, not updatable
    private String firstName;            // Required, max 10 chars
    private String lastName;             // Required, max 10 chars
    private String phone;                // Required, exactly 10 digits
    private String address;              // Required, max 30 chars

    /**
     * Constructor that initializes a contact and validates all fields.
     *
     * @param contactId unique ID (non-null, max 10 characters)
     * @param firstName first name (non-null, max 10 characters)
     * @param lastName last name (non-null, max 10 characters)
     * @param phone phone number (non-null, exactly 10 digits)
     * @param address address (non-null, max 30 characters)
     * @throws IllegalArgumentException if any field is invalid
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null || contactId.trim().isEmpty() || contactId.length() > 10)
            throw new IllegalArgumentException("Contact ID must be non-null and no more than 10 characters.");
        if (firstName == null || firstName.trim().isEmpty() || firstName.length() > 10)
            throw new IllegalArgumentException("First name must be non-null and no more than 10 characters.");
        if (lastName == null || lastName.trim().isEmpty() || lastName.length() > 10)
            throw new IllegalArgumentException("Last name must be non-null and no more than 10 characters.");
        if (phone == null || !phone.matches("\\d{10}"))
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        if (address == null || address.trim().isEmpty() || address.length() > 30)
            throw new IllegalArgumentException("Address must be non-null and no more than 30 characters.");

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Getter: returns the contact ID (read-only)
    public String getContactId() {
        return contactId;
    }

    // Getter: returns the contact's first name
    public String getFirstName() {
        return firstName;
    }

    // Getter: returns the contact's last name
    public String getLastName() {
        return lastName;
    }

    // Getter: returns the contact's phone number
    public String getPhone() {
        return phone;
    }

    // Getter: returns the contact's address
    public String getAddress() {
        return address;
    }

    // Setter: updates the first name with validation
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.trim().isEmpty() || firstName.length() > 10)
            throw new IllegalArgumentException("First name must be non-null and no more than 10 characters.");
        this.firstName = firstName;
    }

    // Setter: updates the last name with validation
    public void setLastName(String lastName) {
        if (lastName == null || lastName.trim().isEmpty() || lastName.length() > 10)
            throw new IllegalArgumentException("Last name must be non-null and no more than 10 characters.");
        this.lastName = lastName;
    }

    // Setter: updates the phone number with validation
    public void setPhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}"))
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        this.phone = phone;
    }

    // Setter: updates the address with validation
    public void setAddress(String address) {
        if (address == null || address.trim().isEmpty() || address.length() > 30)
            throw new IllegalArgumentException("Address must be non-null and no more than 30 characters.");
        this.address = address;
    }
}