// AppointmentServiceTest.java
// Unit tests for AppointmentService.java to ensure appointments are added, retrieved, and deleted properly.

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentServiceTest {
    private AppointmentService service;
    private Date futureDate;

    // Initializes the service and sets a valid future date before each test
    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        futureDate = cal.getTime();
    }

    // Test adding a valid appointment and verifying it's retrievable
    @Test
    public void testAddAppointment() {
        Appointment appt = new Appointment("007", futureDate, "Mission briefing");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("007"));
    }

    // Test that adding a duplicate appointment ID throws an exception
    @Test
    public void testAddDuplicateThrowsException() {
        Appointment appt1 = new Appointment("007", futureDate, "First");
        Appointment appt2 = new Appointment("007", futureDate, "Second");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    // Test deleting an existing appointment
    @Test
    public void testDeleteAppointment() {
        Appointment appt = new Appointment("007", futureDate, "Delete me");
        service.addAppointment(appt);
        service.deleteAppointment("007");
        assertNull(service.getAppointment("007"));
    }

    // Test deleting a null appointment ID (should do nothing and not throw)
    @Test
    public void testDeleteNullAppointmentIdDoesNothing() {
        assertDoesNotThrow(() -> service.deleteAppointment(null));
        assertNull(service.getAppointment(null)); // Still should be null
    }
}