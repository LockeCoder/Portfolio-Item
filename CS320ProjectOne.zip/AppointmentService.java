// AppointmentService.java
// Manages a collection of Appointment objects using a HashMap for efficient access.

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // HashMap to store appointments, using the appointment ID as the key
    private final Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Adds a new appointment to the service.
     * If an appointment with the same ID already exists, an exception is thrown.
     *
     * @param appt the Appointment object to be added
     * @throws IllegalArgumentException if the appointment ID already exists
     */
    public void addAppointment(Appointment appt) {
        if (appointments.containsKey(appt.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        appointments.put(appt.getAppointmentId(), appt);
    }

    /**
     * Deletes an appointment from the service by ID.
     * If the ID does not exist or is null, nothing happens (no error thrown).
     *
     * @param appointmentId the ID of the appointment to be deleted
     */
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null) {
            return; // Silently ignore null input
        }
        appointments.remove(appointmentId); // Safe: does nothing if ID doesn't exist
    }

    /**
     * Retrieves an appointment by its ID.
     *
     * @param appointmentId the ID of the appointment to retrieve
     * @return the Appointment object if found, otherwise null
     */
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}