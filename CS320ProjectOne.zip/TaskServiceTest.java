// TaskServiceTest.java
// Unit tests for the TaskService class to verify correct task management functionality.

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService service;

    // Runs before each test to reset TaskService instance
    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    // Test: Add a task and verify it can be retrieved by ID
    @Test
    public void testAddTask() {
        Task task = new Task("007", "Mission", "Retrieve intel.");
        service.addTask(task);
        assertEquals(task, service.getTask("007"));
    }

    // Test: Adding a duplicate task ID should throw an exception
    @Test
    public void testAddDuplicateTaskThrows() {
        Task task = new Task("007", "Mission", "Retrieve intel.");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    // Test: Deleting an existing task should remove it from the system
    @Test
    public void testDeleteTask() {
        Task task = new Task("007", "Mission", "Retrieve intel.");
        service.addTask(task);
        service.deleteTask("007");
        assertNull(service.getTask("007"));
    }

    // Test: Attempting to delete a non-existent task should throw an exception
    @Test
    public void testDeleteNonexistentTaskThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }

    // Test: Updating a task's name should reflect the new name
    @Test
    public void testUpdateName() {
        Task task = new Task("007", "Mission", "Retrieve intel.");
        service.addTask(task);
        service.updateName("007", "Infiltrate");
        assertEquals("Infiltrate", service.getTask("007").getName());
    }

    // Test: Updating the name of a non-existent task should throw an exception
    @Test
    public void testUpdateNameInvalidIdThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.updateName("999", "Infiltrate"));
    }

    // Test: Updating a task's description should reflect the new description
    @Test
    public void testUpdateDescription() {
        Task task = new Task("007", "Mission", "Retrieve intel.");
        service.addTask(task);
        service.updateDescription("007", "Enter facility silently.");
        assertEquals("Enter facility silently.", service.getTask("007").getDescription());
    }

    // Test: Updating the description of a non-existent task should throw an exception
    @Test
    public void testUpdateDescriptionInvalidIdThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("999", "Invalid update"));
    }

    // Test: Retrieving a task that doesn't exist should return null
    @Test
    public void testGetNonexistentTaskReturnsNull() {
        assertNull(service.getTask("999"));
    }
}