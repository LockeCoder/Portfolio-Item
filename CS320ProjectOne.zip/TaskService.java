// TaskService.java 
// This class manages Task objects by allowing addition, deletion, and field updates.
// Tasks are stored using a HashMap for constant-time lookup by task ID.

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    // Internal storage of tasks using task ID as the unique key
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a new task to the system if the ID is not already in use.
     *
     * @param task the Task object to add
     * @throws IllegalArgumentException if a task with the same ID already exists
     */
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes an existing task from the system.
     *
     * @param taskId the ID of the task to remove
     * @throws IllegalArgumentException if the task does not exist
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name of the specified task.
     *
     * @param taskId  the ID of the task to update
     * @param newName the new name to assign (validated by Task class)
     * @throws IllegalArgumentException if the task is not found
     */
    public void updateName(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }
        task.setName(newName);
    }

    /**
     * Updates the description of the specified task.
     *
     * @param taskId         the ID of the task to update
     * @param newDescription the new description to assign (validated by Task class)
     * @throws IllegalArgumentException if the task is not found
     */
    public void updateDescription(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }
        task.setDescription(newDescription);
    }

    /**
     * Retrieves a task by its ID.
     *
     * @param taskId the ID of the task to retrieve
     * @return the Task object if found, otherwise null
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}