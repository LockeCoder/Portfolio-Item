import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// Unit tests for the ContactService class to ensure it manages contacts correctly
public class ContactServiceTest {
    private ContactService service;

    // Setup method runs before each test case
    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    // Test: Add a contact and verify it was added successfully
    @Test
    public void testAddContact() {
        Contact contact = new Contact("001", "James", "Bond", "1234567890", "Address One");
        service.addContact(contact);
        assertEquals(contact, service.getContact("001"));
    }

    // Test: Adding a duplicate contact should throw an exception
    @Test
    public void testAddDuplicateContactThrows() {
        Contact contact = new Contact("001", "James", "Bond", "1234567890", "Address One");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    // Test: Delete a contact and verify it no longer exists
    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("001", "James", "Bond", "1234567890", "Address One");
        service.addContact(contact);
        service.deleteContact("001");
        assertNull(service.getContact("001"));
    }

    // Test: Update the first name of a contact
    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("001", "James", "Bond", "1234567890", "Address One");
        service.addContact(contact);
        service.updateFirstName("001", "Jane");
        assertEquals("Jane", service.getContact("001").getFirstName());
    }

    // Test: Update the last name of a contact
    @Test
    public void testUpdateLastName() {
        Contact contact = new Contact("002", "John", "Doe", "1234567890", "Address Two");
        service.addContact(contact);
        service.updateLastName("002", "Smith");
        assertEquals("Smith", service.getContact("002").getLastName());
    }

    // Test: Update the phone number of a contact
    @Test
    public void testUpdatePhone() {
        Contact contact = new Contact("003", "Alice", "Lee", "1234567890", "Address Three");
        service.addContact(contact);
        service.updatePhone("003", "0987654321");
        assertEquals("0987654321", service.getContact("003").getPhone());
    }

    // Test: Update the address of a contact
    @Test
    public void testUpdateAddress() {
        Contact contact = new Contact("004", "Emma", "Brown", "1234567890", "Old Address");
        service.addContact(contact);
        service.updateAddress("004", "New Address");
        assertEquals("New Address", service.getContact("004").getAddress());
    }
}