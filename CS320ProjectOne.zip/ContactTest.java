import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

// Unit tests for the Contact class
public class ContactTest {

    // Test creating a valid contact and verifying all fields
    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("007", "James", "Bond", "1234567890", "MI6 Headquarters");
        assertEquals("007", contact.getContactId());
        assertEquals("James", contact.getFirstName());
        assertEquals("Bond", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("MI6 Headquarters", contact.getAddress());
    }

    // Test updating all mutable fields and verifying changes
    @Test
    public void testFieldUpdates() {
        Contact contact = new Contact("007", "James", "Bond", "1234567890", "MI6 Headquarters");
        contact.setFirstName("Jamie");
        contact.setLastName("Bee");
        contact.setPhone("0987654321");
        contact.setAddress("Q Branch");

        assertEquals("Jamie", contact.getFirstName());
        assertEquals("Bee", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("Q Branch", contact.getAddress());
    }

    // Test that setting a null or overly long first name throws an exception
    @Test
    public void testInvalidFirstNameThrows() {
        Contact contact = new Contact("007", "James", "Bond", "1234567890", "MI6 HQ");
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("ThisNameIsWayTooLong"));
    }

    // Test that setting a null or overly long last name throws an exception
    @Test
    public void testInvalidLastNameThrows() {
        Contact contact = new Contact("007", "James", "Bond", "1234567890", "MI6 HQ");
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ThisLastNameIsTooLong"));
    }

    // Test that setting an invalid phone number throws an exception
    @Test
    public void testInvalidPhoneThrows() {
        Contact contact = new Contact("007", "James", "Bond", "1234567890", "MI6 HQ");
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));               // null phone
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123"));              // too short
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("abcdefghij"));       // non-numeric
    }

    // Test that setting a null or overly long address throws an exception
    @Test
    public void testInvalidAddressThrows() {
        Contact contact = new Contact("007", "James", "Bond", "1234567890", "MI6 HQ");
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));             // null
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("A".repeat(31)));   // > 30 chars
    }

    // Test that exactly 10 digits for a phone number is accepted
    @Test
    public void testPhoneExactly10DigitsAccepted() {
        Contact contact = new Contact("007", "James", "Bond", "0123456789", "MI6 HQ");
        assertEquals("0123456789", contact.getPhone());
    }

    // Test that exactly 30 characters for address is accepted
    @Test
    public void testAddressExactly30CharsAccepted() {
        String address = "X".repeat(30);
        Contact contact = new Contact("007", "James", "Bond", "1234567890", address);
        assertEquals(30, contact.getAddress().length());
    }
}