import java.util.HashMap;
import java.util.Map;

// This service manages a list of Contact objects using a HashMap keyed by contact ID
public class ContactService {
    // Stores contacts using their unique contact ID
    private Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact to the service.
     * Throws an exception if a contact with the same ID already exists.
     *
     * @param contact the Contact object to be added
     */
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    /**
     * Deletes a contact by ID. If the ID does not exist, nothing happens.
     *
     * @param contactId the ID of the contact to be removed
     */
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    /**
     * Updates the first name of a contact if it exists.
     *
     * @param contactId     the ID of the contact
     * @param newFirstName  the new first name to assign
     */
    public void updateFirstName(String contactId, String newFirstName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setFirstName(newFirstName);
        }
    }

    /**
     * Updates the last name of a contact if it exists.
     *
     * @param contactId     the ID of the contact
     * @param newLastName   the new last name to assign
     */
    public void updateLastName(String contactId, String newLastName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setLastName(newLastName);
        }
    }

    /**
     * Updates the phone number of a contact if it exists.
     *
     * @param contactId  the ID of the contact
     * @param newPhone   the new phone number to assign
     */
    public void updatePhone(String contactId, String newPhone) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setPhone(newPhone);
        }
    }

    /**
     * Updates the address of a contact if it exists.
     *
     * @param contactId     the ID of the contact
     * @param newAddress    the new address to assign
     */
    public void updateAddress(String contactId, String newAddress) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setAddress(newAddress);
        }
    }

    /**
     * Retrieves a contact by ID.
     *
     * @param contactId the ID of the contact to retrieve
     * @return the Contact object if found, or null if not found
     */
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}